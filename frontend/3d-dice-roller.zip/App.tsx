import React, { useState } from 'react';
import { ThreeDice } from './components/ThreeDice';
import type { IcosahedronSize, DieType } from './types';

const App: React.FC = () => {
  const [size, setSize] = useState<IcosahedronSize>('medium');
  const [dieType, setDieType] = useState<DieType>(20);
  const [baseColor, setBaseColor] = useState('#D18534');
  const [isDebug, setIsDebug] = useState(false);

  const sizes: IcosahedronSize[] = ['small', 'medium', 'large'];
  const dice: DieType[] = [2, 4, 6, 8, 10, 12, 20];

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-4 antialiased">
      <div className="text-center space-y-4 mb-8">
        <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-orange-500">
          3D Dice Roller
        </h1>
        <p className="text-slate-400 max-w-xl mx-auto">
          A collection of 3D dice spinning in space, built with React and Three.js. Click and drag the die to rotate it. Use the controls below to change the die, size, and color.
        </p>
      </div>

      <div
        className="w-full flex items-center justify-center h-64 sm:h-80 md:h-96 cursor-grab active:cursor-grabbing"
      >
        <ThreeDice dieType={dieType} size={size} baseColor={baseColor} isDebug={isDebug} />
      </div>

      <div className="mt-8 flex flex-col items-center gap-6">
        {/* Die Type Selector */}
        <div className="flex items-center justify-center flex-wrap gap-2 sm:gap-3 p-2 bg-slate-800/50 rounded-xl">
          {dice.map((d) => (
            <button
              key={d}
              onClick={() => setDieType(d)}
              className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg text-sm font-semibold transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-amber-400 ${
                dieType === d
                  ? 'bg-amber-500 text-white shadow-lg'
                  : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              d{d}
            </button>
          ))}
        </div>

        {/* Size and Color Controls */}
        <div className="flex items-center justify-center flex-wrap gap-4">
           <div className="flex items-center justify-center gap-2 sm:gap-3 p-2 bg-slate-800/50 rounded-xl">
            {sizes.map((s) => (
              <button
                key={s}
                onClick={() => setSize(s)}
                className={`px-4 py-1.5 sm:px-5 rounded-lg text-sm capitalize font-semibold transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-amber-400 ${
                  size === s
                    ? 'bg-amber-500 text-white shadow-lg'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <div className="p-2 bg-slate-800/50 rounded-xl flex items-center gap-3">
            <label htmlFor="color-picker" className="text-sm font-semibold text-slate-300 pl-2">Color</label>
            <input
              id="color-picker"
              type="color"
              value={baseColor}
              onChange={(e) => setBaseColor(e.target.value)}
              className="w-10 h-10 bg-transparent rounded-md cursor-pointer border-2 border-slate-700"
              style={{'--webkit-appearance': 'none'} as React.CSSProperties}
            />
          </div>
           <div className="p-2 bg-slate-800/50 rounded-xl flex items-center gap-3">
             <label htmlFor="debug-checkbox" className="text-sm font-semibold text-slate-300 pl-2 select-none cursor-pointer">Debug</label>
            <input
              id="debug-checkbox"
              type="checkbox"
              checked={isDebug}
              onChange={(e) => setIsDebug(e.target.checked)}
              className="w-6 h-6 bg-slate-700 rounded-md cursor-pointer focus:ring-2 focus:ring-amber-400 focus:ring-offset-2 focus:ring-offset-slate-900"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;