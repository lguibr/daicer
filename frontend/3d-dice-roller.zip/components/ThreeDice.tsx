import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import type { DieProps, DieType } from '../types';
import { createDie } from '../utils/three-geometry';

const SIZE_MAP = { small: 0.8, medium: 1.2, large: 1.6 };

// Define a type for our stored Three.js state
interface ThreeState {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  controls: OrbitControls;
  die?: THREE.Group;
  axesHelper?: THREE.AxesHelper;
}

export const ThreeDice: React.FC<DieProps & { dieType: DieType }> = ({
  dieType,
  size,
  baseColor,
  isDebug,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef<ThreeState | null>(null);
  const animationFrameIdRef = useRef<number>();

  // Setup effect runs once on mount
  useEffect(() => {
    if (!mountRef.current) return;
    const currentMount = mountRef.current;
    
    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, currentMount.clientWidth / currentMount.clientHeight, 0.1, 100);
    camera.position.z = 5;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    currentMount.appendChild(renderer.domElement);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.enablePan = false;
    controls.enableZoom = false;
    controls.minPolarAngle = Math.PI / 4;
    controls.maxPolarAngle = (3 * Math.PI) / 4;
    controls.autoRotate = true; // Enable auto-rotation
    controls.autoRotateSpeed = 1.0;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.5);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 2.5);
    directionalLight.position.set(2, 5, 5);
    scene.add(directionalLight);

    // Axes Helper
    const axesHelper = new THREE.AxesHelper(2);
    scene.add(axesHelper);

    // Store state in ref to access it in other effects and cleanup
    stateRef.current = { scene, camera, renderer, controls, axesHelper };

    // Animation loop
    const animate = () => {
      animationFrameIdRef.current = requestAnimationFrame(animate);
      controls.update(); // This will handle both damping and auto-rotation
      renderer.render(scene, camera);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      if (!currentMount || !stateRef.current) return;
      const { camera, renderer } = stateRef.current;
      camera.aspect = currentMount.clientWidth / currentMount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup function
    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
      if (stateRef.current) {
        const { renderer, controls, scene } = stateRef.current;
        controls.dispose();
        // Dispose of all scene objects properly
        scene.traverse(object => {
          if (object instanceof THREE.Mesh) {
            object.geometry.dispose();
            if (Array.isArray(object.material)) {
              object.material.forEach(material => {
                if (material.map) material.map.dispose();
                material.dispose();
              });
            } else if (object.material) {
              if (object.material.map) object.material.map.dispose();
              object.material.dispose();
            }
          }
        });
        renderer.dispose();
        if (currentMount && currentMount.contains(renderer.domElement)) {
            currentMount.removeChild(renderer.domElement);
        }
      }
    };
  }, []); // Empty dependency array ensures this runs only once

  // Effect to handle prop changes
  useEffect(() => {
    if (!stateRef.current) return;
    const { scene, die: currentDie } = stateRef.current;

    // --- Update Die ---
    // If the die type or color has changed, replace the mesh
    if (currentDie && (currentDie.userData.dieType !== dieType || currentDie.userData.baseColor !== baseColor)) {
      scene.remove(currentDie);
      // Properly dispose of the old die's resources by traversing the group
      currentDie.traverse(object => {
        if (object instanceof THREE.Mesh) {
            object.geometry.dispose();
            const material = object.material;
             if (Array.isArray(material)) {
                material.forEach(mat => {
                    if (mat.map) mat.map.dispose();
                    mat.dispose();
                });
            } else if (material) {
                if (material.map) material.map.dispose();
                material.dispose();
            }
        }
      });
      stateRef.current.die = undefined;
    }

    // If there's no die in the scene, create a new one
    if (!stateRef.current.die) {
      const newDie = createDie(dieType, baseColor);
      scene.add(newDie);
      stateRef.current.die = newDie;
    }

    // --- Update Size ---
    const dieToScale = stateRef.current.die;
    if (dieToScale) {
      const scale = SIZE_MAP[size] || 1;
      dieToScale.scale.set(scale, scale, scale);
    }

    // --- Update Debug Axes Visibility ---
    const { axesHelper } = stateRef.current;
    if (axesHelper) {
      axesHelper.visible = isDebug ?? false;
    }

  }, [dieType, size, baseColor, isDebug]);

  return <div ref={mountRef} className="w-full h-full" />;
};
