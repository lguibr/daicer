export type IcosahedronSize = 'small' | 'medium' | 'large';
export type DieType = 2 | 4 | 6 | 8 | 10 | 12 | 20;

export interface DieProps {
  size: IcosahedronSize;
  baseColor: string;
  isDebug?: boolean;
}