import * as THREE from 'three';
import * as BufferGeometryUtils from 'three/addons/utils/BufferGeometryUtils.js';

// --- Data ---
const D10_VERTICES = [
  // Top, Bottom
  new THREE.Vector3(0, 1.3, 0), new THREE.Vector3(0, -1.3, 0),
  // Equatorial
  ...Array.from({ length: 5 }, (_, i) => {
    const angle = (i / 5) * 2 * Math.PI;
    const r = 1;
    return new THREE.Vector3(r * Math.sin(angle), 0, r * Math.cos(angle));
  })
];

const D10_FACES = [
  // Top pyramid
  [0, 2, 3], [0, 3, 4], [0, 4, 5], [0, 5, 6], [0, 6, 2],
  // Bottom pyramid
  [1, 3, 2], [1, 4, 3], [1, 5, 4], [1, 6, 5], [1, 2, 6]
];

// Mapping of numbers to face indices for each die type
// The order corresponds to the face/triangle order in the generated BufferGeometry
const FACE_NUMBER_MAP: Record<number, (number | string)[]> = {
  4: [1, 2, 3, 4],
  6: [1, 6, 2, 5, 3, 4], // BoxGeometry: +X, -X, +Y, -Y, +Z, -Z
  8: [1, 3, 8, 6, 2, 4, 7, 5],
  10: [0, 2, 8, 6, 4, 9, 7, 1, 3, 5],
  12: [12, 2, 8, 5, 10, 4, 11, 9, 6, 3, 7, 1],
  20: [20, 2, 14, 10, 8, 1, 17, 11, 5, 9, 19, 15, 3, 7, 13, 18, 12, 6, 16, 4],
};


// --- Texture Generation ---
const textureCache: Record<string, THREE.CanvasTexture> = {};

function createNumberTexture(number: string): THREE.CanvasTexture {
  const cacheKey = number;
  if (textureCache[cacheKey]) {
    return textureCache[cacheKey];
  }

  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d')!;
  const size = 128; // Higher resolution for crisp numbers
  canvas.width = size;
  canvas.height = size;

  // Transparent background
  context.font = `bold ${size * 0.7}px Arial`;
  context.fillStyle = 'white';
  context.textAlign = 'center';
  context.textBaseline = 'middle';
  context.fillText(number, size / 2, size / 2 + size * 0.04); // slight vertical offset for better centering

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  textureCache[cacheKey] = texture;
  return texture;
}

// --- Helper to create a number plane ---
function createNumberPlane(num: string | number, size: number): THREE.Mesh {
    const texture = createNumberTexture(num.toString());
    const material = new THREE.MeshBasicMaterial({
        map: texture,
        transparent: true,
        depthTest: false, // Render on top of the face
        side: THREE.DoubleSide,
    });
    const geometry = new THREE.PlaneGeometry(size, size);
    return new THREE.Mesh(geometry, material);
}

// --- Geometry & Material Creation ---

function createDieGeometry(type: number): THREE.BufferGeometry {
  switch (type) {
    case 2: return new THREE.CylinderGeometry(1, 1, 0.2, 32); // Coin
    case 4: return new THREE.TetrahedronGeometry(1.2);
    case 6: return new THREE.BoxGeometry(1.5, 1.5, 1.5);
    case 8: return new THREE.OctahedronGeometry(1.1);
    case 10:
      const geom = new THREE.PolyhedronGeometry(
        D10_VERTICES.flatMap(v => v.toArray()),
        D10_FACES.flat(),
        1.1, 0
      );
      geom.rotateX(Math.PI / 2); // Orient it to stand up
      return geom;
    case 12: {
       const dodecaGeom = new THREE.DodecahedronGeometry(1);
       // DodecahedronGeometry is non-indexed by default. We convert it to an
       // indexed geometry so we can correctly group triangles into pentagonal faces.
       const indexedDodeca = BufferGeometryUtils.mergeVertices(dodecaGeom);
       indexedDodeca.rotateX(0.58); // Empirically determined rotation for flat top
       return indexedDodeca;
    }
    case 20: return new THREE.IcosahedronGeometry(1);
    default: return new THREE.IcosahedronGeometry(1);
  }
}

// --- Main Export ---

export function createDie(type: number, color: string): THREE.Group {
  const geometry = createDieGeometry(type);
  const dieGroup = new THREE.Group();
  
  const baseMaterial = new THREE.MeshStandardMaterial({
    color: new THREE.Color(color),
    metalness: 0.2,
    roughness: 0.4,
    transparent: true,
    opacity: 0.9,
  });

  // For all dice, create a single-material body and add number planes on top.
  const dieBody = new THREE.Mesh(geometry, baseMaterial);
  dieGroup.add(dieBody);
  
  const numbers = FACE_NUMBER_MAP[type];
  const positions = geometry.attributes.position;
  const indices = geometry.index;
  
  if (type === 2) {
      const cylinderHeight = 0.2;
      const numberPlaneSize = 1.2;

      // Top face (number 1)
      const topCenter = new THREE.Vector3(0, cylinderHeight / 2, 0);
      const topNormal = new THREE.Vector3(0, 1, 0);
      const topPlane = createNumberPlane('1', numberPlaneSize);
      topPlane.position.copy(topCenter).add(topNormal.clone().multiplyScalar(0.01));
      topPlane.lookAt(topCenter.clone().add(topNormal));
      dieGroup.add(topPlane);
      
      // Bottom face (number 2)
      const bottomCenter = new THREE.Vector3(0, -cylinderHeight / 2, 0);
      const bottomNormal = new THREE.Vector3(0, -1, 0);
      const bottomPlane = createNumberPlane('2', numberPlaneSize);
      bottomPlane.position.copy(bottomCenter).add(bottomNormal.clone().multiplyScalar(0.01));
      bottomPlane.lookAt(bottomCenter.clone().add(bottomNormal));
      dieGroup.add(bottomPlane);

  } else if (type === 6) {
    const numberPlaneSize = 0.8;
    const halfSize = 1.5 / 2; // BoxGeometry was created with size 1.5
    
    // The face order for BoxGeometry is +X, -X, +Y, -Y, +Z, -Z
    const faceData = [
        { normal: new THREE.Vector3(1, 0, 0), center: new THREE.Vector3(halfSize, 0, 0) },
        { normal: new THREE.Vector3(-1, 0, 0), center: new THREE.Vector3(-halfSize, 0, 0) },
        { normal: new THREE.Vector3(0, 1, 0), center: new THREE.Vector3(0, halfSize, 0) },
        { normal: new THREE.Vector3(0, -1, 0), center: new THREE.Vector3(0, -halfSize, 0) },
        { normal: new THREE.Vector3(0, 0, 1), center: new THREE.Vector3(0, 0, halfSize) },
        { normal: new THREE.Vector3(0, 0, -1), center: new THREE.Vector3(0, 0, -halfSize) },
    ];

    for (let i = 0; i < 6; i++) {
        const { normal, center } = faceData[i];
        const numberPlane = createNumberPlane(numbers[i], numberPlaneSize);
        
        // Position the plane slightly off the face
        numberPlane.position.copy(center).add(normal.clone().multiplyScalar(0.02));
        
        // Orient the plane to face outwards
        numberPlane.lookAt(center.clone().add(normal));
        
        dieGroup.add(numberPlane);
    }
  } else if (type === 12) { // Special handling for Dodecahedron (pentagonal faces)
        const numberPlaneSize = 0.5;
        if (!indices) {
             console.error("D12 geometry is unexpectedly not indexed. Cannot place numbers.");
             return dieGroup;
        }
        const faceCount = 12;
        // A dodecahedron's geometry is composed of 36 triangles (12 faces * 3 triangles)
        for (let i = 0; i < faceCount; i++) {
            const tri1_idx = i * 3; // First triangle of the pentagon
            
            // Get the 5 unique vertices of the pentagon face
            const faceVertexIndices = new Set<number>();
            for (let j = 0; j < 3; j++) { // 3 triangles per pentagon
                const triIndex = (i * 3) + j;
                const i3 = triIndex * 3;
                faceVertexIndices.add(indices.getX(i3));
                faceVertexIndices.add(indices.getY(i3));
                faceVertexIndices.add(indices.getZ(i3));
            }

            const faceVertices = Array.from(faceVertexIndices).map(idx =>
                new THREE.Vector3().fromBufferAttribute(positions, idx)
            );
            
            // Calculate center and normal
            const center = faceVertices.reduce((acc, v) => acc.add(v), new THREE.Vector3()).divideScalar(faceVertices.length);
            const i3_tri1 = tri1_idx * 3;
            const vA = new THREE.Vector3().fromBufferAttribute(positions, indices.getX(i3_tri1));
            const vB = new THREE.Vector3().fromBufferAttribute(positions, indices.getY(i3_tri1));
            const vC = new THREE.Vector3().fromBufferAttribute(positions, indices.getZ(i3_tri1));
            const normal = new THREE.Vector3().crossVectors(vB.clone().sub(vA), vC.clone().sub(vA)).normalize();

            const numberPlane = createNumberPlane(numbers[i], numberPlaneSize);
            numberPlane.position.copy(center).add(normal.clone().multiplyScalar(0.01));
            numberPlane.lookAt(center.clone().add(normal));
            dieGroup.add(numberPlane);
        }
    } else { // For other polyhedra (triangular faces)
        const isIndexed = !!indices;
        const faceCount = isIndexed ? indices.count / 3 : positions.count / 3;

        for (let i = 0; i < faceCount; i++) {
            const vA = new THREE.Vector3();
            const vB = new THREE.Vector3();
            const vC = new THREE.Vector3();
            
            if (isIndexed) {
                const i3 = i * 3;
                const ia = indices.getX(i3);
                const ib = indices.getY(i3);
                const ic = indices.getZ(i3);
                vA.fromBufferAttribute(positions, ia);
                vB.fromBufferAttribute(positions, ib);
                vC.fromBufferAttribute(positions, ic);
            } else {
                const i3 = i * 3;
                vA.fromBufferAttribute(positions, i3);
                vB.fromBufferAttribute(positions, i3 + 1);
                vC.fromBufferAttribute(positions, i3 + 2);
            }

            const center = new THREE.Vector3().add(vA).add(vB).add(vC).divideScalar(3);
            const normal = new THREE.Vector3().crossVectors(vB.clone().sub(vA), vC.clone().sub(vA)).normalize();
            
            const numberPlaneSize = type === 4 ? 0.6 : 0.5;
            const numberPlane = createNumberPlane(numbers[i], numberPlaneSize);
            numberPlane.position.copy(center).add(normal.clone().multiplyScalar(0.01));
            numberPlane.lookAt(center.clone().add(normal));
            dieGroup.add(numberPlane);
        }
    }

  dieGroup.name = 'die';
  dieGroup.userData = { dieType: type, baseColor: color }; // Store metadata on the group
  return dieGroup;
}